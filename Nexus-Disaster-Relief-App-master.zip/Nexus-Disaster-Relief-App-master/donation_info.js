document.addEventListener('DOMContentLoaded', function () {
    // Close button functionality
    document.getElementById('close-info').addEventListener('click', function () {
        history.back();
    });
});
